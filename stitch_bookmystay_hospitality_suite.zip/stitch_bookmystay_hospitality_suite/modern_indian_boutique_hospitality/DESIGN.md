---
name: Modern Indian Boutique Hospitality
colors:
  surface: '#ecfef0'
  surface-dim: '#cdded1'
  surface-bright: '#ecfef0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e6f8eb'
  surface-container: '#e0f2e5'
  surface-container-high: '#dbeddf'
  surface-container-highest: '#d5e7da'
  on-surface: '#101f17'
  on-surface-variant: '#424844'
  inverse-surface: '#25342b'
  inverse-on-surface: '#e3f5e8'
  outline: '#737973'
  outline-variant: '#c2c8c2'
  surface-tint: '#4c6455'
  primary: '#071e13'
  on-primary: '#ffffff'
  primary-container: '#1d3327'
  on-primary-container: '#839c8c'
  inverse-primary: '#b3cdbb'
  secondary: '#9d431f'
  on-secondary: '#ffffff'
  secondary-container: '#fe8c62'
  on-secondary-container: '#742502'
  tertiary: '#28004f'
  on-tertiary: '#ffffff'
  tertiary-container: '#440080'
  on-tertiary-container: '#b37bf6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cfe9d7'
  primary-fixed-dim: '#b3cdbb'
  on-primary-fixed: '#092015'
  on-primary-fixed-variant: '#354c3f'
  secondary-fixed: '#ffdbcf'
  secondary-fixed-dim: '#ffb59b'
  on-secondary-fixed: '#380d00'
  on-secondary-fixed-variant: '#7e2c08'
  tertiary-fixed: '#eedbff'
  tertiary-fixed-dim: '#dab9ff'
  on-tertiary-fixed: '#2a0053'
  on-tertiary-fixed-variant: '#5f259f'
  background: '#ecfef0'
  on-background: '#101f17'
  surface-variant: '#d5e7da'
typography:
  display-lg:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system reflects modern Indian boutique hospitality tailored for independent properties (10–60 rooms). It bridges heritage warmth with clean, high-efficiency digital utility. The visual voice is poised, transparent, and grounded—evoking the serenity of a bespoke plantation retreat or restored haveli, backed by modern transactional speed.

The design movement synthesizes **Modern Organic Minimalism** with **Tactile Warmth**:
- Generous architectural balance pairing crisp ivory surfaces against warm linen backgrounds.
- High-contrast, friction-free readability designed mobile-first for guests booking on 4G networks or hoteliers managing check-ins on the move.
- Culturally intuitive trust signals: native UPI cues, localized direct-booking assurances, and instant WhatsApp concierge integration.

## Colors
The palette balances natural botanicals with functional transactional clarity:

- **Primary (`#1D3327`)**: Deep Forest Green. Anchor for primary buttons, core navigation bars, authoritative headings, and secure state banners.
- **Secondary (`#C25E38`)**: Earthy Terracotta. Active accents, urgent callouts, promotional tags, select CTAs, and warm highlights.
- **Tertiary (`#5F259F`)**: Verified UPI Purple. Reserved strictly for direct digital payments, UPI payment flows, verified banking credentials, and quick-pay accordions.
- **Trust Success (`#15803D`)**: Emerald Green. Used exclusively for verified boutique status, WhatsApp integration touchpoints, and instant room confirmation badges.
- **Backgrounds**: Canvas sits on warm parchment (`#FAF8F4` base, `#F4F1EA` subtle alt), contrasted by crisp `#FFFFFF` cards to provide clean visual lift.
- **Neutrals (`#4A5A50`, `#718077`, `#E5E0D8`)**: Slate and muted sage tones ensure secondary labels, line dividers, and tabular pricing grids maintain high legibility without pure black harshness.

## Typography
The typographic hierarchy establishes dual rhythms:
1. **Editorial Sophistication**: **Noto Serif** provides literary dignity and heritage hospitality presence for hotel names, room category titles, quotes, and property hero blocks.
2. **Operational Clarity**: **Plus Jakarta Sans** delivers fast scannability, open counters, and high distinction across digits and monetary values (₹/INR), critical for mobile booking flows.

Guidelines:
- Never apply all-caps styling to long serif headings; reserve uppercase transformations strictly for `label-sm` metadata and status indicators.
- Numeric pricing strings must strictly use Plus Jakarta Sans to prevent uneven numeral baselines.

## Layout & Spacing
A fluid 4-column layout on mobile scales to an 8-column layout on tablet, and a 12-column layout on desktop (max width: 1280px). 

Rhythm rules:
- **Mobile-First Priority**: Screen edge margins are fixed at `1rem` on viewports under 640px to maximize tap surface for room gallery carousels and room selection cards.
- **Vertical Spacing**: Form controls, room selection cards, and breakdown items adopt a strict 8px increment cadence (`space-sm` for inline badges, `space-md` for form fields, `space-lg` between distinct reservation modules).
- **Sticky Affordance**: Mobile layouts reserve an 80px safe area at the viewport bottom for fixed booking conversion bars containing room rates, direct-booking incentives, and checkout CTAs.

## Elevation & Depth
Depth is created through clean surface layering and delicate tinted ambient shadows, avoiding dark grey drop-shadows:

- **Surface Tiers**:
  - `Base`: Canvas parchment (`#FAF8F4`).
  - `Card Surface`: Pure flat white (`#FFFFFF`) with a 1px border in `#E5E0D8`.
  - `Overlay & Sticky Bars`: Crisp white with an ambient warm shadow: `0 8px 24px -4px rgba(29, 51, 39, 0.08)`.
- **Modals & Drawers**: Backdrop overlay uses a calibrated `#1D3327` with 45% opacity and a 4px blur, maintaining brand immersion even behind datepickers and room detail sheets.
- **Tactile States**: Interactive elements (such as room filter pills and booking buttons) do not elevate dramatically; instead, they shift border weight or background density on active states.

## Shapes
The shape system uses a balanced rounded architecture (0.5rem base) to maintain modern architectural structure while providing approachable hospitality softness:

- **Cards & Room Units**: Standard `0.5rem` (`rounded-md`) corners ensure clean grid alignment when cards are stacked in listings.
- **Interactive Modals & Bottom Sheets**: Top corners styled with `rounded-xl` (`1.5rem`) for comfortable mobile drawer interactions.
- **Pill Badges & Direct Actions**: Status pills, verification tags, and primary action buttons utilize full pill radii (`9999px`) to distinguish actionable controls from layout containers.

## Components

### Buttons
- **Primary Action (Book Direct / Confirm)**: Deep Forest Green background (`#1D3327`), crisp white text, full pill radius, minimum height 48px for effortless mobile thumb targeting.
- **WhatsApp Concierge**: Emerald Green background (`#15803D`) or white pill with `#15803D` border/icon, accompanied by standard prompt copy: *"Chat with Host"*.
- **Secondary / Ghost**: Parchment background with 1.5px `#1D3327` outline and slate text.

### Badges & Pill Tags
- **Trust Verified Stamp**: Full pill radius, warm parchment background (`#F4F1EA`), `#1D3327` text, prepended with a crisp checkmark icon (`#15803D`).
- **Direct Deal Tag**: Terracotta background (`#C25E38`) with crisp white label text for discounts, inclusions (e.g., *"Free Breakfast"*), or limited inventory alerts.
- **UPI Instant Pay Tag**: Subtle purple tint background (`rgba(95, 37, 159, 0.08)`) with `#5F259F` label and genuine UPI symbol for clear zero-fee payment indicators.

### Cards & Room Units
- **Room Option Card**: White `#FFFFFF` card, 1px `#E5E0D8` border, 8px radius. Features an edge-to-edge 16:10 aspect image carousel, followed by a padded content container containing room title in Noto Serif, amenity badges in Plus Jakarta Sans, and an integrated pricing strip.

### Pricing Breakdown Matrix
- Clean tabular breakdown displaying Base Room Rate, Local Taxes (GST/Luxury tax clearly separated), and Green "Direct Booking Savings" subtraction lines. Total net payable is rendered in bold 20px Plus Jakarta Sans alongside instant UPI/Card badges.

### Input Fields & Selectors
- Background `#FFFFFF`, 1.5px neutral border (`#D8D3CA`), 8px radius, height 48px. Active focus transitions border color to `#1D3327` with no aggressive outer glow rings. Date inputs provide wide tap spaces with calendar glyphs styled in Terracotta `#C25E38`.

### Mobile Navigation & Sticky Footer
- **Bottom Navigation Bar**: Fixed bottom bar with 4 standard tabs (Explore, My Stays, Concierge/WhatsApp, Account) highlighted with Deep Forest Green active markers.
- **Checkout Sticky Footer**: Split footer with total price (including tax breakdown link) on the left and a high-contrast pill CTA on the right.